#!/bin/sh

cd /app
socat tcp-listen:9011,fork,reuseaddr exec:./chall &
while true; do sleep 1; done